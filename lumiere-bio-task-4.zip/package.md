# Task 4, remaining form steps. Both blocks answered 3 against a GTFA of 8.

Run from the zip with md5 4fd6ea16b32788860d8d46d1ad747ca9, image md5 1a710b26c94cf37807392a4ee9129803.
Do not change the image or the prompt, both blocks have already run against them. Everything
below is the rest of the form, in platform order. Every field carries KaTeX on its numbers, as
the project announcement asks.

---

## Step 6. GTFA

$8$

Final Answer field: 8

---

## Step 7. Image description

Image 1 is a self authored diagram of a signalling network, drawn in the convention used for
Boolean models of regulation, on a plain white background at $3000 \times 2400$ pixels. There
is no photograph, no magnification and no staining to report. Twelve proteins, named with the
capital letters A, B, C, D, E, F, G, H, J, K, L and M, sit as cream circles with black rims on
one large ring, with F at the top and the others spaced evenly round it. Every regulatory link
is a straight coloured line between two circles. A green line which ends in a pointed arrowhead
means the protein at the tail activates the protein at the head. A red line which ends in a
short flat bar means the protein at the tail inhibits the protein at the bar. A small legend at
the bottom left shows one of each. There are $36$ links and they cross one another many times
inside the ring, so each line has to be followed from end to end at full resolution. Where two
proteins regulate each other the two lines run side by side a short distance apart, each with
its own end marker. No protein has a link to itself, and no numbers or words are printed on the
lines.

Read by the protein at the head, the links are these. A is activated by C, by J and by B. B is
activated by J, and inhibited by A, by H and by L. C is activated by D, and inhibited by M and
by K. D is activated by F and by B, and inhibited by A. E is activated by F and by M. F is
activated by B, by G, by C and by H. G is activated by K and by H, and inhibited by E. H is
activated by J and by F, and inhibited by G and by L. J is activated by H, by K and by D. K is
activated by D and by F, and inhibited by J. L is activated by F and inhibited by M. M is
activated by H and inhibited by K.

That gives $24$ activating links and $12$ inhibiting links. Five pairs of proteins regulate each
other in both directions: A and B, F and H, G and H, H and J, and J and K. The lines are crisp,
the colours are saturated, and the end markers are large enough to tell apart at full
resolution. The picture carries no starting state, no time axis and no result of any kind.

---

## Step 8. Model failure mode

Select: visual misinterpretation of the diagram, arrow direction and link type misread, which
is the topology failure mode. If a second choice is offered, select miscounting in a dense
field.

Justification, Response 1:

> Response 1 answered $3$. It applied the stated threshold rule correctly to the network it
> believed it saw, but that network was not the one drawn. It read the red bar from A to B as an
> activation, read the green arrows from F to E and from M to E as running the other way, so
> that E activated F and M, and gave D an activating link to H which does not exist. Its first
> update therefore switched on B, F and H, where the drawn network switches on C, J and K, and
> from there its trajectory had nothing in common with the true one. It reached a state which
> repeated after three updates and reported $3$. Every step of its arithmetic is right for the
> links it listed, so the error is in reading the figure and not downstream. The result is five
> steps short of the GTFA of $8$.

Justification, Response 2:

> Response 2 answered $3$ by the same route. Its first state was B, F, H and M active, which
> requires A to activate B, E to activate F and M, and D or E to reach H, and none of those
> links is drawn in that direction or with that sign. It then carried the rule forward correctly
> on that wrong network and found a state which repeated after three updates. The reading error
> is in the direction of the arrows into E and the type of the link from A to B, which is a bar
> and not an arrowhead. The arithmetic that follows is sound, so the failure is in the figure
> reading. The result is $3$ against a GTFA of $8$.

---

## Step 9. Step-by-step solution

Step 1. Image 1 is a ring of twelve proteins joined by $36$ straight links. Green lines with
arrowheads are activations and red lines with flat bars are inhibitions, as the legend at the
bottom left shows. The arrowhead or bar marks the protein being regulated.

Step 2. Read every link at full resolution and list the regulators of each protein. A plus sign
marks an activator and a minus sign an inhibitor.

| protein | regulators |
|---|---|
| A | C+, J+, B+ |
| B | A-, J+, H-, L- |
| C | M-, D+, K- |
| D | F+, B+, A- |
| E | F+, M+ |
| F | B+, G+, C+, H+ |
| G | K+, H+, E- |
| H | G-, L-, J+, F+ |
| J | H+, K+, D+ |
| K | D+, J-, F+ |
| L | F+, M- |
| M | K-, H+ |

Step 3. The update rule from the prompt. All twelve proteins update at once from the previous
state. A protein is active after the update when the number of its active activators is
strictly greater than the number of its active inhibitors, and inactive otherwise. Write each
tally as activators against inhibitors.

Step 4. Update $1$, from A, D and E active. C has D active as an activator and nothing active
against it, $1$ against $0$, so C switches on. J has D, $1$ against $0$, on. K has D, $1$
against $0$, on. B has A active as an inhibitor, $0$ against $1$, off. D has A as an inhibitor,
$0$ against $1$, off. G has E as an inhibitor, $0$ against $1$, off. A, E, F, H, L and M have no
active regulator, $0$ against $0$, off. State after $1$ update: C, J, K.

Step 5. Update $2$. A: C and J, $2$ against $0$, on. B: J, $1$ against $0$, on. F: C, $1$
against $0$, on. G: K, $1$ against $0$, on. H: J, $1$ against $0$, on. J: K, $1$ against $0$,
on. C: K inhibits, $0$ against $1$, off. K: J inhibits, $0$ against $1$, off. M: K inhibits,
$0$ against $1$, off. D, E, L: $0$ against $0$, off. State: A, B, F, G, H, J.

Step 6. Update $3$. A: J and B, $2$ against $0$, on. B: J against A and H, $1$ against $2$,
off. D: F and B against A, $2$ against $1$, on. E: F, $1$ against $0$, on. F: B, G and H, $3$
against $0$, on. G: H, $1$ against $0$, on. H: J and F against G, $2$ against $1$, on. J: H,
$1$ against $0$, on. K: F against J, $1$ against $1$, off. L: F, $1$ against $0$, on. M: H,
$1$ against $0$, on. C: $0$ against $0$, off. State: A, D, E, F, G, H, J, L, M.

Step 7. Update $4$. A: J, $1$ against $0$, on. B: J against A, H and L, $1$ against $3$, off.
C: D against M, $1$ against $1$, off. D: F against A, $1$ against $1$, off. E: F and M, $2$
against $0$, on. F: G and H, $2$ against $0$, on. G: H against E, $1$ against $1$, off. H: J
and F against G and L, $2$ against $2$, off. J: H and D, $2$ against $0$, on. K: D and F
against J, $2$ against $1$, on. L: F against M, $1$ against $1$, off. M: H, $1$ against $0$,
on. State: A, E, F, J, K, M.

Step 8. Update $5$. A: J, on. B: J against A, $1$ against $1$, off. C: M and K inhibit, $0$
against $2$, off. D: F against A, $1$ against $1$, off. E: F and M, $2$ against $0$, on. F: $0$
against $0$, off. G: K against E, $1$ against $1$, off. H: J and F, $2$ against $0$, on. J: K,
$1$ against $0$, on. K: F against J, $1$ against $1$, off. L: F against M, $1$ against $1$,
off. M: K inhibits, $0$ against $1$, off. State: A, E, H, J.

Step 9. Update $6$. A: J, on. B: J against A and H, $1$ against $2$, off. D: A inhibits, off.
F: H, $1$ against $0$, on. G: H against E, $1$ against $1$, off. H: J, $1$ against $0$, on. J:
H, on. K: J inhibits, off. M: H, $1$ against $0$, on. C, E, L: $0$ against $0$, off. State: A,
F, H, J, M.

Step 10. Update $7$. A: J, on. B: J against A and H, off. C: M inhibits, off. D: F against A,
$1$ against $1$, off. E: F and M, $2$ against $0$, on. F: H, on. G: H, $1$ against $0$, on. H:
J and F, $2$ against $0$, on. J: H, on. K: F against J, $1$ against $1$, off. L: F against M,
$1$ against $1$, off. M: H, on. State: A, E, F, G, H, J, M.

Step 11. Update $8$. A: J, on. B: off as before. C: M inhibits, off. D: F against A, off. E: F
and M, on. F: G and H, $2$ against $0$, on. G: H against E, $1$ against $1$, off. H: J and F
against G, $2$ against $1$, on. J: H, on. K: F against J, off. L: F against M, off. M: H, on.
State: A, E, F, H, J, M.

Step 12. Update $9$ from A, E, F, H, J, M. A: J, on. B: J against A and H, off. C: M, off. D: F
against A, off. E: F and M, on. F: H, $1$ against $0$, on. G: H against E, $1$ against $1$,
off. H: J and F, $2$ against $0$, on. J: H, on. K: F against J, off. L: F against M, off. M: H,
on. State: A, E, F, H, J, M, the same as after update $8$.

Step 13. The state after $8$ updates equals the state after $9$, and the states after $0$ to
$8$ updates are all different from the one which follows each of them. The smallest $t$ with
the required property is therefore $t = 8$.

Final answer: $8$

---

## Step 10. Distractors

Distractors (incorrect answers only). Note that in testing we provided the model all potential
answers, including the GTFA.

| Value | Error it encodes |
|---|---|
| $3$ | Reads the two arrows into E as leaving E and the bar from A to B as an arrowhead, so the first update switches on B, F and H instead of C, J and K, and a false fixed point appears after three updates. This was both responses. |
| $5$ | Reads the head of the red bar from A to B as landing on M instead, which sends the early trajectory through a different path and settles it three steps early. |
| $7$ | Loses one activating link into A, for example reads the arrow from C to A as ending at E, so A drops out one step sooner and the network settles after seven updates. |
| $10$ | Drops the activation of C by D, or reads the inhibition of C by M as coming from A or E, which lets C linger and delays settling by two updates. |
| $11$ | Reads the arrow from J to A as ending at M, or the arrow from C to A as starting from D, which keeps D and K oscillating for three more updates. |

---

## Step 11. Science Judge

Nothing to enter unless the judge raises a finding. If it raises a finding which quotes the
approval checkbox as the prompt, or says the update rule is unstated, use the wording from the
playbook under task-pass-experience section 4, the rule is in the third paragraph of the prompt.

---

## Prompt Checker rebuttal, DOMAIN_KNOWLEDGE_FLOOR

Use the Disagree control with this text:

> The expertise the task tests is reading a regulatory network drawn in the standard systems
> biology convention, pointed arrowheads for activation and flat bars for inhibition, with
> thirty six links crossing on a ring, and applying the synchronous threshold update used in
> Boolean models of signalling. The nodes are proteins because that is the object such models
> describe. Replacing their names with neutral labels changes nothing about the diagram which
> has to be read, and that diagram is where both tested responses failed: each read arrows into
> E as arrows out of E and a bar from A to B as an arrowhead. The update rule is stated because
> threshold models come in more than one convention and the task would be ambiguous without it.
