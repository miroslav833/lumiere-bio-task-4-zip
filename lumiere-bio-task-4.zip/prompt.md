Image 1 shows a signalling network of twelve proteins drawn as a "threshold Boolean network". Each circle is one protein, which is either active or inactive at any time. A green arrow from one protein to another means the first activates the second, and a red line ending in a flat bar means the first inhibits the second. Every regulatory link in the network is drawn and there are no others, and no protein regulates itself.

At time $0$ the proteins A, D and E are active and every other protein is inactive. Find the number of update steps the network takes to settle, which is the smallest $t$ for which the state after $t$ updates is the same as the state after $t+1$ updates.

There are some things which stay fixed. All proteins update together at each step, from the state at the previous step only. A protein is active after an update when the number of its activators which were active before the update is strictly greater than the number of its inhibitors which were active before the update, and it is inactive otherwise, whatever its own previous state was. Each link counts once, with equal weight, and a protein with no active regulator becomes inactive.

Report your final answer as a single integer.
