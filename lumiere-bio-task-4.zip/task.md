# Biology task 4, attempt 1: settling time of a threshold Boolean signalling network

Status: NOT YET RUN.

How to run it. Fill the form from the table, upload image.png, paste prompt.md word for word.
Tick boxes 1, 3 and 4 and leave box 2 for Miroslav. Wait for both model blocks and save them as
feedback/001.md with the expected answer, the verdict, the checker findings and both blocks in
full with their reasoning. The answer is an integer, so any block which says 8 is right and the
run is over. Both have to miss.

| Field | Value |
|---|---|
| Subdomain | Cell Biology / Molecular Cell Biology |
| Where did the image(s) come from | Original - internal lab image |
| Source URL or DOI | N/A |
| License | Original - internal lab image |
| Reference material | N/A |
| Publication venue | N/A |
| Image | image.png, 3000 x 2400, twelve nodes, 36 links |

---

## Step 4. Prompt

In prompt.md. Paste that file and nothing else.

---

## Step 6. GTFA

8

---

## Checkboxes

| Statement | Answer |
|---|---|
| I've double checked my spelling and grammar. | True |
| My prompt is not duplicative, plagiarized, or LLM-generated. | Box 2 is Miroslav's, leave it |
| My prompt is self-contained and fully solvable without external resources. | True |
| The prompt can only be solved with the information in the image. | True |

NON_FOUNDATIONAL_REFERENCE fires on every image task, record it and carry on. The prompt states
the update rule in full because threshold networks come in several conventions and the task is
ambiguous without one; the hard part is reading 36 links off a ring with 235 crossings and
carrying all twelve states through nine updates without a slip.

---

## Ground truth

Inputs of every protein, read from the generator and not from the picture. A plus sign is an
activator and a minus sign an inhibitor.

| protein | regulators |
|---|---|
| A | C+, J+, B+ |
| B | A-, J+, H-, L- |
| C | M-, D+, K- |
| D | F+, B+, A- |
| E | F+, M+ |
| F | B+, G+, C+, H+ |
| G | K+, H+, E- |
| H | G-, L-, J+, F+ |
| J | H+, K+, D+ |
| K | D+, J-, F+ |
| L | F+, M- |
| M | K-, H+ |

Trajectory from A, D, E active. Each row lists the active proteins after that many updates.

| t | active |
|---|---|
| 0 | A D E |
| 1 | C J K |
| 2 | A B F G H J |
| 3 | A D E F G H J L M |
| 4 | A E F J K M |
| 5 | A E H J |
| 6 | A F H J M |
| 7 | A E F G H J M |
| 8 | A E F H J M |
| 9 | A E F H J M |

The state after 8 updates equals the state after 9, and no earlier pair of consecutive states
matches, so the answer is 8. The fixed point has six proteins active.

Checked by tools/boolnet.py, which also enumerated every single link misread, 624 of them: a
link dropped, its sign flipped, its head moved to another node, or its tail moved. 453 of the 624
change the answer. 192 of them send the network into a cycle with no fixed point at all, and the
rest spread over 4, 5, 6, 7, 9, 10, 11, 12, 13 and higher. Only 171 leave the answer at 8.

## Where the levers are

This is the design shape of the one task in the whole project that reached the submit button,
the CS task graph: a dense labelled graph and a deterministic multistep simulation on it, where
the models applied the method correctly to a graph they had misread. Nothing here is measured.
Everything is traced, and one wrong arrow changes the trajectory from step 2 onwards.

1. 36 chords on a ring of twelve, 235 crossings. Five antiparallel pairs, A and B, F and H, G and H, H and J,
   and J and K, drawn as separate offset lines with their own end markers.
2. Two kinds of end marker on two colours. An arrowhead read as a bar, or the reverse, flips
   a sign, and 36 of the 36 sign flips were tested: most change the answer.
3. The simulation has to be carried for nine updates over twelve proteins, with three or four
   regulators each. The chain is long enough that one slip anywhere propagates.
4. Three of the earlier biology designs were solved because the model could trace every line.
   Here the figure is built so that tracing is the hard part.

## Wrong answers and what each one means

| answer | what happened |
|---|---|
| 7 | one link misread, most often a dropped activator somewhere in the F, H, J cluster |
| 6 or 5 | a dropped or flipped link on the early path through C, J, K |
| 9 or 10 | a misread that delays the collapse of G or L by a step |
| 11 to 13 | a misread that lets D or K oscillate a while longer |
| 2 or 3 | the network run with the rule read as "active if any activator is active" |
| no fixed point | 192 of the single misreads produce a cycle; a block that reports a cycle has misread the figure |

Every wrong integer is at least one step out, which is at least 12 percent of 8, so there is no
near miss inside the tolerance band.
