# lumiere-bio-task-4

One Lumiere task in the Biology domain, subdomain Cell Biology / Molecular Cell Biology. The
image is a self authored threshold Boolean signalling network: twelve proteins on a ring, 36
activating and inhibiting links, 235 crossings. The question asks how many synchronous updates
the network takes to settle from a given start. The answer is 8.

| File | What it holds |
|---|---|
| prompt.md | the prompt, the only text anybody pastes into the form |
| task.md | the form fields, the regulator table, the full trajectory, the levers, the wrong answers |
| image.png | the network, 3000 x 2400 |
| truth.json | edges, trajectory, and the answer every single link misread would give |
| tools/boolnet.py | generates the network, lays it out, simulates it, and scans misreads |
| feedback/ | one file per run, written after the models answer |

This follows the shape of the one design in the project which reached the submit button: a
dense labelled graph and a deterministic multistep simulation, where the models applied the
method correctly to a graph they had misread.
