#!/usr/bin/env python3
"""Threshold Boolean signalling network on a ring, with a steps-to-fixed-point question.

python3 boolnet.py search N      scan seeds
python3 boolnet.py build SEED    write fig.svg, fig.html, truth.json
"""
import sys, os, json, random, math, itertools

NODES = list("ABCDEFGHJKLM")          # 12 nodes, no I to avoid confusion with 1
W, H = 3000, 2400
CX, CY, RING, R = 1500, 1200, 880, 62
FONT = "Liberation Sans, Arial, Helvetica, sans-serif"

def make_net(seed):
    rnd = random.Random(seed)
    edges = {}                         # (src, dst) -> +1 / -1
    for dst in NODES:
        k = rnd.choice((2, 3, 3, 3, 4))
        srcs = rnd.sample([n for n in NODES if n != dst], k)
        for s in srcs:
            edges[(s, dst)] = 1 if rnd.random() < 0.6 else -1
    # every node must have at least one output
    for n in NODES:
        if not any(s == n for s, d in edges):
            d = rnd.choice([m for m in NODES if m != n])
            edges[(n, d)] = 1 if rnd.random() < 0.6 else -1
    return edges

def step(state, edges):
    nxt = {}
    for n in NODES:
        act = sum(1 for (s, d), t in edges.items() if d == n and t > 0 and state[s])
        inh = sum(1 for (s, d), t in edges.items() if d == n and t < 0 and state[s])
        nxt[n] = 1 if act > inh else 0
    return nxt

def run(edges, init, maxsteps=40):
    """returns (t, trajectory) where t is the smallest t with S(t) == S(t+1), or None if it cycles"""
    s = {n: (1 if n in init else 0) for n in NODES}
    traj = [s]
    seen = {tuple(s[n] for n in NODES): 0}
    for t in range(maxsteps):
        s2 = step(s, edges)
        traj.append(s2)
        if s2 == s:
            return t, traj
        key = tuple(s2[n] for n in NODES)
        if key in seen:
            return None, traj
        seen[key] = t + 1
        s = s2
    return None, traj

def answer(edges, init):
    t, traj = run(edges, init)
    return t

def perturbations(edges):
    """every single-edge misread: drop it, flip its sign, move its head to a neighbour node,
    move its tail to a neighbour node"""
    out = []
    for (s, d), t in edges.items():
        e = dict(edges); del e[(s, d)]; out.append(("drop", s, d, e))
        e = dict(edges); e[(s, d)] = -t; out.append(("flip", s, d, e))
        for d2 in NODES:
            if d2 in (s, d) or (s, d2) in edges: continue
            e = dict(edges); del e[(s, d)]; e[(s, d2)] = t; out.append(("head", s, d, e))
        for s2 in NODES:
            if s2 in (s, d) or (s2, d) in edges: continue
            e = dict(edges); del e[(s, d)]; e[(s2, d)] = t; out.append(("tail", s, d, e))
    return out

# ---------------------------------------------------------------- geometry
def pos_of(order):
    return {n: (CX + RING * math.cos(2 * math.pi * i / len(NODES) - math.pi / 2),
                CY + RING * math.sin(2 * math.pi * i / len(NODES) - math.pi / 2)) for i, n in enumerate(order)}

def seg_dist(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay; L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))

def ends(pos, s, d):
    (x1, y1), (x2, y2) = pos[s], pos[d]
    L = math.hypot(x2 - x1, y2 - y1); ux, uy = (x2 - x1) / L, (y2 - y1) / L
    return (x1 + ux * (R + 4), y1 + uy * (R + 4)), (x2 - ux * (R + 10), y2 - uy * (R + 10))

def seg_intersect(p1, p2, p3, p4):
    def ccw(a, b, c): return (c[1] - a[1]) * (b[0] - a[0]) > (b[1] - a[1]) * (c[0] - a[0])
    return ccw(p1, p3, p4) != ccw(p2, p3, p4) and ccw(p1, p2, p3) != ccw(p1, p2, p4)

def layout_score(edges, pos):
    segs = {e: ends(pos, *e) for e in edges}
    hits = 0
    for (s, d), (a, b) in segs.items():
        for n in NODES:
            if n in (s, d): continue
            if seg_dist(pos[n][0], pos[n][1], a[0], a[1], b[0], b[1]) < R + 30: hits += 1
    # antiparallel pairs overlap exactly; offset them in render, but count them
    cross = 0
    for (e1, s1), (e2, s2) in itertools.combinations(segs.items(), 2):
        if set(e1) & set(e2): continue
        if seg_intersect(s1[0], s1[1], s2[0], s2[1]): cross += 1
    return hits, cross

def best_order(edges, seed, tries=300):
    rnd = random.Random(seed + 99)
    best = None
    for _ in range(tries):
        order = NODES[:]; rnd.shuffle(order)
        pos = pos_of(order)
        hits, cross = layout_score(edges, pos)
        key = (hits, -cross)
        if best is None or key < best[0]: best = (key, order, pos, hits, cross)
    return best

def evaluate(seed):
    edges = make_net(seed)
    rnd = random.Random(seed * 3 + 7)
    # initial state: three nodes on
    init = set(rnd.sample(NODES, 3))
    t = answer(edges, init)
    if t is None or not (5 <= t <= 10): return None
    pert = perturbations(edges)
    changed = sum(1 for _, _, _, e in pert if answer(e, init) != t)
    frac = changed / len(pert)
    return dict(seed=seed, edges=edges, init=sorted(init), t=t, frac=frac, nedges=len(edges), npert=len(pert))

def render(edges, pos, init):
    out = []; w = out.append
    w(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
    w(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')
    w('<defs><marker id="act" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">'
      '<path d="M 0 0 L 10 5 L 0 10 z" fill="#1b7f3b"/></marker>'
      '<marker id="inh" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">'
      '<rect x="6" y="0" width="3" height="10" fill="#b4232a"/></marker></defs>')
    for (s, d), t in edges.items():
        a, b = ends(pos, s, d)
        # antiparallel partner: offset both sideways so they do not overlap
        off = 0
        if (d, s) in edges:
            dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy); nx, ny = -dy / L, dx / L
            off = 14
            a = (a[0] + nx * off, a[1] + ny * off); b = (b[0] + nx * off, b[1] + ny * off)
        col = "#1b7f3b" if t > 0 else "#b4232a"
        mk = "act" if t > 0 else "inh"
        w(f'<line x1="{a[0]:.1f}" y1="{a[1]:.1f}" x2="{b[0]:.1f}" y2="{b[1]:.1f}" stroke="{col}" stroke-width="4" marker-end="url(#{mk})"/>')
    for n, (x, y) in pos.items():
        w(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{R}" fill="#fbf7ea" stroke="#1a1a1a" stroke-width="4"/>')
        w(f'<text x="{x:.1f}" y="{y + 2:.1f}" font-family="{FONT}" font-size="54" font-weight="bold" text-anchor="middle" dominant-baseline="middle" fill="#1a1a1a">{n}</text>')
    # legend
    lx, ly = 160, H - 110
    w(f'<line x1="{lx}" y1="{ly}" x2="{lx + 140}" y2="{ly}" stroke="#1b7f3b" stroke-width="4" marker-end="url(#act)"/>')
    w(f'<text x="{lx + 170}" y="{ly}" font-family="{FONT}" font-size="34" dominant-baseline="middle">activates</text>')
    w(f'<line x1="{lx + 420}" y1="{ly}" x2="{lx + 560}" y2="{ly}" stroke="#b4232a" stroke-width="4" marker-end="url(#inh)"/>')
    w(f'<text x="{lx + 590}" y="{ly}" font-family="{FONT}" font-size="34" dominant-baseline="middle">inhibits</text>')
    w('</svg>')
    return "\n".join(out)

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    mode = sys.argv[1]
    if mode == "search":
        rows = []
        for seed in range(int(sys.argv[2])):
            e = evaluate(seed)
            if not e or e["frac"] < 0.85: continue
            lay = best_order(e["edges"], seed, tries=150)
            if lay[3]: continue
            rows.append((e["frac"], lay[4], seed, e["t"], e["nedges"], e["init"]))
            print(f"seed {seed:4d} steps {e['t']:2d} edges {e['nedges']:2d} crossings {lay[4]:3d} sensitivity {e['frac']:.2f} init {e['init']}", flush=True)
        rows.sort(reverse=True)
        print("BEST:", rows[:6])
    else:
        seed = int(sys.argv[2])
        e = evaluate(seed)
        lay = best_order(e["edges"], seed, tries=2000)
        key, order, pos, hits, cross = lay
        svg = render(e["edges"], pos, e["init"])
        open(os.path.join(here, "fig.svg"), "w").write(svg)
        open(os.path.join(here, "fig.html"), "w").write('<html><head><meta charset="utf-8"></head><body style="margin:0;background:#fff">' + svg + '</body></html>')
        t, traj = run(e["edges"], set(e["init"]))
        pert = perturbations(e["edges"])
        dist = {}
        for kind, s, d, ed in pert:
            a = answer(ed, set(e["init"])); dist[a] = dist.get(a, 0) + 1
        json.dump(dict(seed=seed, init=e["init"], answer=t, edges={f"{s}->{d}": v for (s, d), v in e["edges"].items()},
                       order=order, crossings=cross, hits=hits, sensitivity=e["frac"],
                       trajectory=[[n for n in NODES if st[n]] for st in traj],
                       wrong_answer_distribution={str(k): v for k, v in sorted(dist.items(), key=lambda kv: (kv[0] is None, kv[0]))}),
                  open(os.path.join(here, "truth.json"), "w"), indent=1)
        print(f"seed {seed}: answer {t} steps, {len(e['edges'])} edges, crossings {cross}, hits {hits}, sensitivity {e['frac']:.2f}")
        print("init ON:", e["init"])
        for i, st in enumerate(traj):
            print(f"  t={i:2d}  ON: {' '.join(n for n in NODES if st[n]) or '-'}")
        print("inputs per node:")
        for n in NODES:
            ins = [(s, '+' if v > 0 else '-') for (s, d), v in e["edges"].items() if d == n]
            print(f"  {n}: " + ", ".join(f"{s}{v}" for s, v in ins))
        print("wrong answers from single misreads:", dist)
